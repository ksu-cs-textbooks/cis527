import unittest
import subprocess
import Levenshtein
import os


class DiffTest():
    def __init__(self, *args, **kwargs):
        # TODO CHANGEME Input student program here
        self.student_file = "/home/codio/workspace/python/Project.py"

    def inputFiles(self):
        pass

    def outputFiles(self):
        pass

    def debugMessages(self):
        pass

    #
    # DO NOT MODIFY THE CODE BELOW
    #

    def runTests(self, logger):
        inputs = self.inputFiles()
        outputs = self.outputFiles()
        messages = self.debugMessages()

        totalScore = 0.0
        numTests = 0

        results = []

        # Run tests in terminal
        for i in range(0, len(inputs)):
            result = {}
            result['testType'] = "File Input"
            result['inputFile'] = os.path.basename(inputs[i])
            result['outputFile'] = os.path.basename(outputs[i])
            result['message'] = messages[i]

            result['expectedOutput'] = "\n".join(self._fileToList(outputs[i]))
            result['programOutput'] = "\n".join(self._runTestFile(inputs[i]))
            result['score'] = self._diff(result['expectedOutput'], result['programOutput'])

            results.append(result)

        # Run tests in file
        for i in range(0, len(inputs)):
            result = {}
            result['testType'] = "Terminal Input"
            result['inputFile'] = os.path.basename(inputs[i])
            result['outputFile'] = os.path.basename(outputs[i])
            result['message'] = messages[i]

            result['expectedOutput'] = "\n".join(self._fileToList(outputs[i]))
            result['programOutput'] = "\n".join(self._runTestTerminal(inputs[i]))
            result['score'] = self._diff(result['expectedOutput'], result['programOutput'])

            results.append(result)

        return results

    def _fileToList(self, file):
        expectedFile = open(file)
        expectedList = expectedFile.readlines()
        outlist = []
        for line in expectedList:
            outlist.append(line.strip())
        return outlist

    def _runTestTerminal(self, file):
        inputFile = open(file)
        try:
            output = subprocess.check_output(["python3", self.student_file], stdin=inputFile, stderr=subprocess.STDOUT,
                                             timeout=10)
        except subprocess.CalledProcessError as exc:
            output = exc.output
        output = output.decode("utf-8")
        outputList = [y for y in (x.strip() for x in output.splitlines()) if y]
        return outputList

    def _runTestFile(self, file):
        try:
            output = subprocess.check_output(
                ["python3", self.student_file, file],
                stderr=subprocess.STDOUT, timeout=10)
        except subprocess.CalledProcessError as exc:
            output = exc.output
        output = output.decode("utf-8")
        outputList = [y for y in (x.strip() for x in output.splitlines()) if y]
        return outputList

    def _diff(self, output, expected):
        dist = Levenshtein.distance(output, expected)
        score = 1.0 - (dist / max(len(output), len(expected)))
        return score

